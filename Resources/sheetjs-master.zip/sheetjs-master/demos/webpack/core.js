/* xlsx.js (C) 2013-present  SheetJS -- http://sheetjs.com */
var XLSX = require('./xlsx.core.min');
console.log("it works!");
module.exports = XLSX;
