# vue-modify

This demo shows import an export with `vue3-table-light` table component.

In this directory, run

```bash
npm i
npm run dev
```
