# react-modify

This demo shows import and export with the `react-data-grid` table component.

In the project directory, you can run:

```bash
$ npm install
$ npm start
```
