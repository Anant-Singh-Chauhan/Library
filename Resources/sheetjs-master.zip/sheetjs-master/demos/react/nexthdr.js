/* xlsx.js (C) 2013-present  SheetJS -- http://sheetjs.com */
import * as XLSX from 'xlsx';
import React from 'react';
